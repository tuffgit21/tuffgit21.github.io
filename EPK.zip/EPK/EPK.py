import time
import sys
print("Welcome To EPK! type 'epk help' to see commands: ")
Epic_Package_Kit = input("$>")
#---EPK HELP---
if Epic_Package_Kit == "epk help":
    print("EPK Commands:")
    print("epk find - Search for a specific package.")
    print("epk install - Installs a specific package.")
    print("epk upgrade - Updates the package list.")
    print("epk destroy - Uninstalls a specific package.")
    print("epk list - Lists all installed packages.")
    print("epk help - Displays this help message.")
    print("epk fetch - Fetches the latest package information.")
    return_to_menu = input("Press Enter to return to the main menu...")
#---EPK FIND---
elif Epic_Package_Kit == "epk find":
    PackageName = input("Enter the package name: ")
    print("Searching for the package:", PackageName)
    for i in range(101):
        sys.stdout.write("\rLooking for package... {}%".format(i))
        sys.stdout.flush()
        time.sleep(1) 
    print("\nPackage: ", PackageName, " found!")
    input("Press Enter to continue...")
#---EPK INSTALL---
elif Epic_Package_Kit == "epk install":
    PackageName = input("Enter the package name: ")
    print("Installing the package:", PackageName)
    for i in range(101):
        sys.stdout.write("\rInstalling package... {}%".format(i))
        sys.stdout.flush()
        time.sleep(1)
        import urllib.request
        if PackageName == "RobloxStudioInstaller":
            url = "https://setup.rbxcdn.com/RobloxStudioInstaller.exe"
            urllib.request.urlretrieve(url, "RobloxStudioInstaller.exe")
        else:
            print("Package not found!")
            input("Press Enter to continue...")
            exit()
    print("\nPackage: ", PackageName, " installed!")
    input("Press Enter to continue...")
#---EPK UPGRADE---
elif Epic_Package_Kit == "epk upgrade":
    print("Upgrading package list...")
    for i in range(101):
        sys.stdout.write("\rUpgrading... {}%".format(i))
        sys.stdout.flush()
        time.sleep(1)
        print("\nPackage list upgraded!")
        input("Press Enter to continue...")
#---EPK DESTROY---
elif Epic_Package_Kit == "epk destroy":
    PackageName = input("Enter the package name: ")
    print("Uninstalling the package:", PackageName)
    if PackageName == PackageName:
        for i in range(101):
            sys.stdout.write("\rUninstalling package... {}%".format(i))
            sys.stdout.flush()
            time.sleep(1)
        print("\nPackage: ", PackageName, " uninstalled!")
        input("Press Enter to continue...")
    else:
        print("Package not found!")
        input("Press Enter to continue...")
        exit()
    
#---EPK LIST---
elif Epic_Package_Kit == "epk list":
    print("Listing all installed packages...")
    for i in range(101):
        sys.stdout.write("\rListing packages... {}%".format(i))
        sys.stdout.flush()
        time.sleep(1)
        print("\nInstalled packages:")
        print("- RobloxStudioInstaller")
        input("Press Enter to continue...")
#---EPK FETCH---
elif Epic_Package_Kit == "epk fetch":
    print("Fetching the latest package information...")
    for i in range(101):
        sys.stdout.write("\rFetching... {}%".format(i))
        sys.stdout.flush()
        time.sleep(1)
        print("\nPackage information fetched!")
        input("Press Enter to continue...")
